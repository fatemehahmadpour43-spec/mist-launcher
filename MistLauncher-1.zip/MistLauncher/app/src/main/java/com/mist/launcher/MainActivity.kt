package com.mist.launcher

import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val homePressed = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF9DD4C3))) {
                LauncherRoot(homePressed)
            }
        }
    }

    /** دکمه خانه وقتی لانچر باز است: کشو و پنجره‌ها بسته شوند و به صفحه اصلی برگردیم. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homePressed.tryEmit(Unit)
    }
}

private const val PAGE_COUNT = 4
private const val HOME_PAGE = 1

@Composable
fun LauncherRoot(homePressed: SharedFlow<Unit>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { LauncherPrefs(ctx) }
    val repo = remember { AppRepository(ctx) }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    val pager = rememberPagerState(initialPage = HOME_PAGE) { PAGE_COUNT }
    var drawerOpen by remember { mutableStateOf(false) }
    var drawerFocus by remember { mutableStateOf(false) }
    val dialogs = remember { mutableStateListOf<DialogRequest>() }

    // هر بار که لانچر جلو می‌آید فهرست برنامه‌ها تازه می‌شود (نصب/حذف برنامه)
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { scope.launch { apps = repo.load() } }

    LaunchedEffect(Unit) {
        homePressed.collect {
            drawerOpen = false
            dialogs.clear()
            pager.animateScrollToPage(HOME_PAGE)
        }
    }

    // انتخاب عکس از گالری؛ دسترسی دائمی گرفته می‌شود تا بعد از ری‌استارت هم بماند
    var pendingKey by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val key = pendingKey
        if (uri != null && key != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            prefs.set(key, uri.toString())
        }
        pendingKey = null
    }

    val state = LauncherState(
        prefs = prefs,
        apps = apps,
        pickImage = { key -> pendingKey = key; picker.launch(arrayOf("image/*")) },
        openDialog = { dialogs.add(it) },
        openDrawer = { focus -> drawerFocus = focus; drawerOpen = true },
    )

    BackHandler(enabled = !drawerOpen) { scope.launch { pager.animateScrollToPage(HOME_PAGE) } }

    CompositionLocalProvider(LocalLauncher provides state) {
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    var acc = 0f
                    detectVerticalDragGestures(
                        onDragStart = { acc = 0f },
                        onDragEnd = { if (acc < -120f) { drawerFocus = false; drawerOpen = true } },
                    ) { _, d -> acc += d }
                },
        ) {
            Wallpaper(prefs.get("wallpaper"))

            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                HorizontalPager(pager, Modifier.weight(1f), beyondViewportPageCount = 1) { page ->
                    when (page) {
                        0 -> ClockPage()
                        1 -> HomePage1()
                        2 -> HomePage2()
                        else -> HomePage3()
                    }
                }
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    PageDots(PAGE_COUNT, pager.currentPage)
                }
                AnimatedVisibility(pager.currentPage != 0, enter = fadeIn(), exit = fadeOut()) { Dock() }
                if (pager.currentPage == 0) Spacer(Modifier.height(78.dp))
            }

            AnimatedVisibility(
                drawerOpen,
                enter = slideInVertically(tween(280)) { it / 3 } + fadeIn(tween(220)),
                exit = slideOutVertically(tween(220)) { it / 3 } + fadeOut(tween(180)),
            ) { AppDrawer(drawerFocus) { drawerOpen = false } }

            dialogs.lastOrNull()?.let { req ->
                val close = { dialogs.remove(req); Unit }
                when (req) {
                    is DialogRequest.EditText -> EditTextDialog(req, close)
                    is DialogRequest.PickApps -> PickAppsDialog(req, close)
                    DialogRequest.Countdown -> CountdownDialog(close)
                    DialogRequest.Settings -> SettingsDialog(close)
                }
            }
        }
    }
}

@Composable
private fun Wallpaper(uri: String?) {
    val custom = rememberUriBitmap(uri, 2400)
    if (custom != null) {
        Image(custom, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    } else {
        Image(painterResource(R.drawable.wallpaper), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
    // کمی تیرگی پایین صفحه تا ویجت‌ها و داک خوانا بمانند
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(0f to Color.Transparent, 0.55f to Color(0x22000000), 1f to Color(0x77000000))
        )
    )
}

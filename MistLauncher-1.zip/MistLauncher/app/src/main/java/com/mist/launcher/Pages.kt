package com.mist.launcher

import android.content.Intent
import android.provider.MediaStore
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

/** قاب مشترک هر صفحه: فاصله‌ها + نگه‌داشتن طولانی روی فضای خالی = تنظیمات */
@Composable
fun PageFrame(content: @Composable ColumnScope.() -> Unit) {
    val l = LocalLauncher.current
    Column(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures(onLongPress = { l.openDialog(DialogRequest.Settings) }) }
            .padding(horizontal = 22.dp)
            .padding(top = 20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        content = content,
    )
}

/* ---------------- صفحه ۰: ساعت بزرگ ---------------- */

@Composable
fun ClockPage() {
    val l = LocalLauncher.current
    val ctx = LocalContext.current
    val now = rememberNow()
    val alarm = nextAlarmText()
    Box(Modifier.fillMaxSize()) {
        PageFrame {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.Eco, null, tint = Color(0xFF2E7D4F), modifier = Modifier.size(26.dp))
                Spacer(Modifier.height(10.dp))
                Text(formatDate(now, l.jalali), color = MistTeal, fontSize = 20.sp)
                Text(
                    formatTime(now).digits(l.faDigits),
                    style = TextStyle(
                        fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold,
                        fontSize = 108.sp, color = MistTeal, letterSpacing = (-2).sp,
                    ),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    PhotoWidget("photo_clock", Modifier.width(96.dp).height(40.dp), RoundedCornerShape(14.dp))
                    Chip(Icons.Outlined.Alarm, alarm?.digits(l.faDigits) ?: "—")
                    Chip(Icons.Outlined.CalendarMonth, formatDate(now, !l.jalali, "d MMM"))
                }
            }
        }
        RoundButton(
            Icons.Outlined.PhotoCamera, "دوربین",
            Modifier.align(Alignment.BottomEnd).padding(24.dp),
        ) { ctx.safeStart(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
    }
}

@Composable
private fun Chip(icon: ImageVector, text: String) {
    Column(
        Modifier.glass(RoundedCornerShape(14.dp), alpha = 0.30f).padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = MistTeal, modifier = Modifier.size(16.dp))
        Text(text, color = MistTeal, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

/* ---------------- صفحه ۱ ---------------- */

private val SOCIAL = listOf(
    "org.telegram.messenger", "com.whatsapp", "com.instagram.android", "com.zhiliaoapp.musically", "com.twitter.android",
)
private val TOOLS = listOf(
    "com.google.android.youtube", "com.spotify.music", "com.google.android.apps.maps", "com.google.android.apps.photos",
)
private val UTIL = listOf(
    "com.android.settings", "com.google.android.calculator", "com.google.android.deskclock", "com.android.vending",
)

@Composable
fun HomePage1() = PageFrame {
    SearchBarWidget()
    PhotoWidget("photo_wide", Modifier.fillMaxWidth().aspectRatio(1.9f))
    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            FolderWidget("folder_1", SOCIAL, 0, Modifier.fillMaxWidth())
            CountdownWidget()
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            QuoteWidget("quote_1", "آرام باش؛ جنگل هم آهسته رشد می‌کند", Modifier.fillMaxWidth().height(64.dp))
            PhotoWidget("photo_tall", Modifier.fillMaxWidth().aspectRatio(0.85f))
        }
    }
}

/* ---------------- صفحه ۲ ---------------- */

@Composable
fun HomePage2() = PageFrame {
    val l = LocalLauncher.current
    val now = rememberNow()
    val hour = Calendar.getInstance().apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY)
    Row(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(30.dp), tint = Color(0xFF5E7466), alpha = 0.55f)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(greeting(hour), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(formatDate(now, l.jalali, "EEEE d MMMM y"), color = SoftWhite.copy(0.8f), fontSize = 13.sp)
        }
        Text(formatTime(now).digits(l.faDigits), color = Color.White, fontSize = 30.sp, fontFamily = FontFamily.Serif)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        QuoteWidget("quote_2", "هر صبح، یک شروع تازه است", Modifier.weight(1f).height(60.dp))
        QuoteWidget("quote_3", "مه می‌رود، کوه می‌ماند", Modifier.weight(1f).height(60.dp))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        FolderWidget("folder_2", TOOLS, 4, Modifier.weight(1f))
        PhotoWidget("photo_2", Modifier.weight(1f).aspectRatio(1f))
    }
}

/* ---------------- صفحه ۳ ---------------- */

@Composable
fun HomePage3() = PageFrame {
    val l = LocalLauncher.current
    val now = rememberNow()
    RingsWidget()
    PhotoWidget("photo_big", Modifier.fillMaxWidth().aspectRatio(1.15f), RoundedCornerShape(32.dp))
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        val (b, _) = rememberBattery()
        Icon(Icons.Outlined.Forest, null, tint = Color.White, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(8.dp))
        Text("باتری ${"$b".digits(l.faDigits)}٪", color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(formatDate(now, l.jalali, "EEE d MMM"), color = Color.White, fontSize = 13.sp)
            Text(formatTime(now).digits(l.faDigits), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
        val apps = l.prefs.list("row_3").mapNotNull { l.appById(it) }.ifEmpty { pickDefaults(l.apps, UTIL, 8) }
        val edit = { l.openDialog(DialogRequest.PickApps("row_3", apps.map { it.id })) }
        AppIcon(apps.getOrNull(0), 60.dp, edit)
        AppIcon(apps.getOrNull(1), 60.dp, edit)
        PhotoWidget("photo_pill", Modifier.weight(1f).height(60.dp), RoundedCornerShape(30.dp))
    }
}

/* ---------------- داک و نشانگر صفحه ---------------- */

@Composable
fun RoundButton(icon: ImageVector, desc: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.size(58.dp).glass(RoundedCornerShape(20.dp), alpha = 0.18f).press(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = SoftWhite, modifier = Modifier.size(26.dp)) }
}

@Composable
fun Dock() {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 26.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        RoundButton(Icons.Outlined.Call, "تلفن") { ctx.safeStart(Intent(Intent.ACTION_DIAL)) }
        RoundButton(Icons.Outlined.ChatBubbleOutline, "پیام") {
            ctx.safeStart(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING))
        }
        RoundButton(Icons.Outlined.Language, "مرورگر") {
            ctx.safeStart(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER))
        }
        RoundButton(Icons.Outlined.PhotoCamera, "دوربین") {
            ctx.safeStart(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        }
    }
}

@Composable
fun PageDots(count: Int, current: Int) {
    Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        repeat(count) { i ->
            Box(
                Modifier
                    .size(if (i == current) 8.dp else 6.dp)
                    .background(Color.White.copy(if (i == current) 0.95f else 0.45f), CircleShape)
            )
        }
    }
}

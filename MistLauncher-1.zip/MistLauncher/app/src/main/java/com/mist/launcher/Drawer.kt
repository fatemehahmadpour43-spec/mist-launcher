package com.mist.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/* ---------------- کشوی برنامه‌ها ---------------- */

@Composable
fun AppDrawer(focusSearch: Boolean, onClose: () -> Unit) {
    val l = LocalLauncher.current
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val filtered = remember(query, l.apps) {
        if (query.isBlank()) l.apps else l.apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    BackHandler(onBack = onClose)
    LaunchedEffect(focusSearch) { if (focusSearch) focus.requestFocus() }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xE60E1C17))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 16.dp),
    ) {
        // دستگیره: با کشیدن به پایین بسته می‌شود
        Box(
            Modifier
                .fillMaxWidth()
                .height(28.dp)
                .pointerInput(Unit) {
                    var acc = 0f
                    detectVerticalDragGestures(
                        onDragStart = { acc = 0f },
                        onDragEnd = { if (acc > 80f) onClose() },
                    ) { _, d -> acc += d }
                },
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.size(40.dp, 4.dp).background(Color.White.copy(0.4f), CircleShape)) }

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().focusRequester(focus),
            placeholder = { Text("جستجو…") },
            leadingIcon = { Icon(Icons.Outlined.Search, null) },
            singleLine = true,
            shape = CircleShape,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { filtered.firstOrNull()?.let { ctx.launchApp(it); onClose() } }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = Color.White.copy(0.5f), unfocusedBorderColor = Color.White.copy(0.2f),
                focusedLeadingIconColor = Color.White, unfocusedLeadingIconColor = Color.White.copy(0.7f),
                focusedPlaceholderColor = Color.White.copy(0.5f), unfocusedPlaceholderColor = Color.White.copy(0.5f),
                cursorColor = Color.White,
            ),
        )
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            items(filtered, key = { it.id }) { app ->
                Column(
                    Modifier.press(onClick = { ctx.launchApp(app); onClose() }, onLongClick = { ctx.openAppInfo(app) }),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    AppIcon(app, 56.dp, onLongClick = { ctx.openAppInfo(app) }, onClick = { ctx.launchApp(app); onClose() })
                    Spacer(Modifier.height(4.dp))
                    Text(
                        app.label, color = Color.White, fontSize = 11.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                    )
                }
            }
        }
    }
}

/* ---------------- پنجره‌ها ---------------- */

@Composable
private fun GlassDialog(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Color(0xF2182C24), RoundedCornerShape(28.dp))
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content,
        )
    }
}

@Composable
private fun DialogTitle(t: String) = Text(t, color = Color.White, fontSize = 18.sp)

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    focusedBorderColor = Color.White.copy(0.6f), unfocusedBorderColor = Color.White.copy(0.25f),
    focusedLabelColor = Color.White, unfocusedLabelColor = Color.White.copy(0.6f), cursorColor = Color.White,
)

@Composable
private fun Actions(onCancel: () -> Unit, onSave: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        TextButton(onCancel) { Text("انصراف", color = Color.White.copy(0.7f)) }
        TextButton(onSave) { Text("ذخیره", color = Color(0xFF9DD4C3)) }
    }
}

@Composable
fun EditTextDialog(req: DialogRequest.EditText, onDone: () -> Unit) {
    val l = LocalLauncher.current
    var text by remember { mutableStateOf(req.default) }
    GlassDialog(onDone) {
        DialogTitle(req.title)
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), colors = fieldColors(), maxLines = 4)
        Actions(onDone) { l.prefs.set(req.key, text.trim().ifEmpty { null }); onDone() }
    }
}

@Composable
fun PickAppsDialog(req: DialogRequest.PickApps, onDone: () -> Unit) {
    val l = LocalLauncher.current
    val chosen = remember { mutableStateListOf<String>().apply { addAll(req.current) } }
    GlassDialog(onDone) {
        DialogTitle("انتخاب برنامه‌ها (حداکثر ۴)")
        LazyColumn(Modifier.heightIn(max = 380.dp)) {
            items(l.apps, key = { it.id }) { app ->
                val on = app.id in chosen
                Row(
                    Modifier.fillMaxWidth().press(onClick = {
                        if (on) chosen.remove(app.id) else if (chosen.size < 4) chosen.add(app.id)
                    }).padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Checkbox(on, null, colors = CheckboxDefaults.colors(checkedColor = Color(0xFF5E9C8A)))
                    Spacer(Modifier.width(8.dp))
                    Text(app.label, color = Color.White)
                }
            }
        }
        Actions(onDone) { l.prefs.setList(req.key, chosen.toList()); onDone() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CountdownDialog(onDone: () -> Unit) {
    val l = LocalLauncher.current
    var title by remember { mutableStateOf(l.prefs.get("cd_title", "تولدم 🎂")!!) }
    val (m, d) = l.prefs.get("cd_md", "03-21")!!.split('-').map { it.toInt() }
    val initial = runCatching { LocalDate.now().withMonth(m).withDayOfMonth(d) }.getOrElse { LocalDate.now() }
        .atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli()
    val state = rememberDatePickerState(initialSelectedDateMillis = initial)
    var pickDate by remember { mutableStateOf(false) }

    if (pickDate) {
        DatePickerDialog(
            onDismissRequest = { pickDate = false },
            confirmButton = { TextButton({ pickDate = false }) { Text("تأیید") } },
        ) { DatePicker(state) }
    }
    GlassDialog(onDone) {
        DialogTitle("شمارش معکوس")
        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("عنوان") }, colors = fieldColors(), singleLine = true)
        val sel = state.selectedDateMillis?.let { Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate() }
        OutlinedButton({ pickDate = true }, Modifier.fillMaxWidth()) {
            Text(sel?.let { formatDate(it.atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli(), l.jalali, "d MMMM") } ?: "انتخاب تاریخ", color = Color.White)
        }
        Actions(onDone) {
            l.prefs.set("cd_title", title.trim().ifEmpty { "رویداد" })
            sel?.let { l.prefs.set("cd_md", "%02d-%02d".format(it.monthValue, it.dayOfMonth)) }
            onDone()
        }
    }
}

@Composable
fun SettingsDialog(onDone: () -> Unit) {
    val l = LocalLauncher.current
    val ctx = LocalContext.current
    GlassDialog(onDone) {
        DialogTitle("تنظیمات لانچر")
        SettingRow("انتخاب به‌عنوان لانچر پیش‌فرض") {
            ctx.safeStart(android.content.Intent(android.provider.Settings.ACTION_HOME_SETTINGS)); onDone()
        }
        SettingRow("تغییر والپیپر") { l.pickImage("wallpaper"); onDone() }
        if (l.prefs.get("wallpaper") != null) SettingRow("برگشت به والپیپر جنگل") { l.prefs.set("wallpaper", null) }
        SettingRow("ویرایش شمارش معکوس") { l.openDialog(DialogRequest.Countdown) }
        Toggle("آیکون‌های کم‌رنگ (هماهنگ با تم)", l.mono) { l.prefs.setFlag("mono_icons", it) }
        Toggle("تاریخ شمسی", l.jalali) { l.prefs.setFlag("jalali", it) }
        Toggle("اعداد فارسی در ساعت", l.faDigits) { l.prefs.setFlag("fa_digits", it) }
        Text(
            "راهنما: روی هر ویجت انگشت را نگه دارید تا عکس، متن یا برنامه‌هایش را عوض کنید. برای باز کردن همه برنامه‌ها، صفحه را به بالا بکشید.",
            color = Color.White.copy(0.6f), fontSize = 12.sp, lineHeight = 18.sp,
        )
    }
}

@Composable
private fun SettingRow(text: String, onClick: () -> Unit) {
    Text(
        text, color = Color.White, fontSize = 15.sp,
        modifier = Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp), alpha = 0.08f).press(onClick = onClick).padding(14.dp),
    )
}

@Composable
private fun Toggle(text: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(value, onChange, colors = SwitchDefaults.colors(checkedTrackColor = Color(0xFF5E9C8A)))
    }
}

package com.mist.launcher

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Calendar
import java.util.Date
import java.util.Locale

/* ---------------- رنگ‌ها و افکت شیشه ---------------- */

val MistTeal = Color(0xFF2B6B61)
val DeepMoss = Color(0xFF1E3A30)
val SoftWhite = Color(0xFFF2F5F3)
val TextShadow = Shadow(Color(0x66000000), Offset(0f, 2f), 6f)

fun Modifier.glass(
    shape: Shape = RoundedCornerShape(26.dp),
    tint: Color = Color.White,
    alpha: Float = 0.20f,
): Modifier = this
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(tint.copy(alpha = alpha + 0.06f), tint.copy(alpha = (alpha - 0.06f).coerceAtLeast(0.02f)))
        )
    )
    .border(
        1.dp,
        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.45f), Color.White.copy(alpha = 0.06f))),
        shape,
    )

@OptIn(ExperimentalFoundationApi::class)
fun Modifier.press(onClick: () -> Unit = {}, onLongClick: (() -> Unit)? = null) =
    combinedClickable(onClick = onClick, onLongClick = onLongClick)

private val monoFilter = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0.12f) })

/* ---------------- آیکون برنامه ---------------- */

@Composable
fun AppIcon(app: AppInfo?, size: Dp = 56.dp, onLongClick: (() -> Unit)? = null, onClick: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    val l = LocalLauncher.current
    Box(
        Modifier
            .size(size)
            .glass(RoundedCornerShape(size * 0.32f), alpha = 0.16f)
            .press(onClick = { onClick?.invoke() ?: app?.let { ctx.launchApp(it) } }, onLongClick = onLongClick),
        contentAlignment = Alignment.Center,
    ) {
        if (app != null) {
            Image(
                app.icon, app.label,
                Modifier
                    .size(size * 0.62f)
                    .clip(RoundedCornerShape(size * 0.18f)),
                colorFilter = if (l.mono) monoFilter else null,
                alpha = if (l.mono) 0.9f else 1f,
            )
        }
    }
}

/* ---------------- پوشه ۲×۲ ---------------- */

@Composable
fun FolderWidget(key: String, candidates: List<String>, skip: Int, modifier: Modifier = Modifier) {
    val l = LocalLauncher.current
    val saved = l.prefs.list(key).mapNotNull { l.appById(it) }
    val apps = saved.ifEmpty { pickDefaults(l.apps, candidates, skip) }
    val edit = { l.openDialog(DialogRequest.PickApps(key, apps.map { it.id })) }
    Box(
        modifier
            .aspectRatio(1f)
            .glass(RoundedCornerShape(30.dp), alpha = 0.14f)
            .press(onLongClick = edit)
            .padding(14.dp),
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
            for (row in 0..1) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    for (col in 0..1) AppIcon(apps.getOrNull(row * 2 + col), 50.dp, onLongClick = edit)
                }
            }
        }
    }
}

/* ---------------- عکس ---------------- */

@Composable
fun PhotoWidget(key: String, modifier: Modifier, shape: Shape = RoundedCornerShape(28.dp)) {
    val l = LocalLauncher.current
    val uri = l.prefs.get(key)
    val bmp = rememberUriBitmap(uri)
    Box(
        modifier
            .glass(shape, alpha = 0.14f)
            .press(onClick = { if (uri == null) l.pickImage(key) }, onLongClick = { l.pickImage(key) }),
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) {
            Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(DeepMoss.copy(alpha = 0.18f)))
        } else {
            Icon(Icons.Outlined.AddPhotoAlternate, "افزودن عکس", tint = SoftWhite.copy(0.8f), modifier = Modifier.size(28.dp))
        }
    }
}

/* ---------------- جمله ---------------- */

@Composable
fun QuoteWidget(key: String, default: String, modifier: Modifier = Modifier) {
    val l = LocalLauncher.current
    val text = l.prefs.get(key, default)!!
    Box(
        modifier
            .glass(RoundedCornerShape(40.dp), tint = Color(0xFF17382B), alpha = 0.72f)
            .press(onLongClick = { l.openDialog(DialogRequest.EditText(key, "متن ویجت", text)) })
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, color = SoftWhite.copy(0.9f), fontSize = 12.sp, fontStyle = FontStyle.Italic,
            textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis, lineHeight = 17.sp,
        )
    }
}

/* ---------------- شمارش معکوس ---------------- */

fun daysUntil(md: String): Int {
    val (m, d) = md.split('-').map { it.toInt() }
    val today = LocalDate.now()
    var target = runCatching { LocalDate.of(today.year, m, d) }.getOrElse { LocalDate.of(today.year, 3, 1) }
    if (target.isBefore(today)) target = target.plusYears(1)
    return ChronoUnit.DAYS.between(today, target).toInt()
}

@Composable
fun CountdownWidget(modifier: Modifier = Modifier) {
    val l = LocalLauncher.current
    val title = l.prefs.get("cd_title", "تولدم 🎂")!!
    val days = daysUntil(l.prefs.get("cd_md", "03-21")!!)
    Column(modifier.press(onLongClick = { l.openDialog(DialogRequest.Countdown) }).padding(8.dp)) {
        val style = TextStyle(color = Color.White, shadow = TextShadow)
        Text(title, style = style, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Text(
            if (days == 0) "همین امروز!" else "${days.toString().digits(l.faDigits)} روز مانده",
            style = style, fontSize = 14.sp,
        )
    }
}

/* ---------------- نوار جستجو ---------------- */

@Composable
fun SearchBarWidget() {
    val l = LocalLauncher.current
    val ctx = LocalContext.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .glass(CircleShape, alpha = 0.24f)
            .press(onClick = { l.openDrawer(true) })
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Outlined.Search, null, tint = SoftWhite)
        Spacer(Modifier.width(10.dp))
        Text("جستجوی برنامه‌ها…", color = SoftWhite.copy(0.75f), fontSize = 14.sp, modifier = Modifier.weight(1f))
        Icon(
            Icons.Outlined.Mic, "جستجوی صوتی", tint = SoftWhite,
            modifier = Modifier.clip(CircleShape).press(onClick = { ctx.safeStart(Intent(Intent.ACTION_VOICE_COMMAND)) }).padding(6.dp),
        )
    }
}

/* ---------------- حلقه‌ها: باتری و پیشرفت زمان ---------------- */

@Composable
fun rememberBattery(): Pair<Int, Boolean> {
    val ctx = LocalContext.current
    var level by remember { mutableIntStateOf(0) }
    var charging by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                level = lv * 100 / sc
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            }
        }
        ContextCompat.registerReceiver(ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    return level to charging
}

@Composable
fun Ring(progress: Float, label: String, caption: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val s = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round)
                drawArc(Color.White.copy(0.18f), 135f, 270f, false, style = s)
                drawArc(color, 135f, 270f * progress.coerceIn(0f, 1f), false, style = s)
            }
            Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Text(caption, color = SoftWhite.copy(0.75f), fontSize = 9.sp)
    }
}

@Composable
fun RingsWidget() {
    val l = LocalLauncher.current
    val (battery, charging) = rememberBattery()
    val now = rememberNow()
    val cal = Calendar.getInstance().apply { timeInMillis = now }
    val dayP = (cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)) / 1440f
    val weekP = (((cal.get(Calendar.DAY_OF_WEEK) - Calendar.SATURDAY + 7) % 7) + dayP) / 7f // هفته از شنبه
    val yearP = cal.get(Calendar.DAY_OF_YEAR) / cal.getActualMaximum(Calendar.DAY_OF_YEAR).toFloat()
    fun pct(p: Float) = "${(p * 100).toInt()}".digits(l.faDigits)
    Row(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(36.dp), tint = Color(0xFF203A31), alpha = 0.55f)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Ring(battery / 100f, pct(battery / 100f), if (charging) "شارژ ⚡" else "باتری", Color(0xFF4ADE80))
        Ring(dayP, pct(dayP), "امروز", Color(0xFF9DD4C3))
        Ring(weekP, pct(weekP), "هفته", Color(0xFF7FB7A6))
        Ring(yearP, pct(yearP), "سال", Color(0xFF5E9C8A))
    }
}

/* ---------------- تاریخ و ساعت ---------------- */

fun formatDate(now: Long, jalali: Boolean, pattern: String = "EEEE d MMMM"): String =
    if (jalali) {
        android.icu.text.SimpleDateFormat(pattern, android.icu.util.ULocale("fa_IR@calendar=persian")).format(Date(now))
    } else {
        java.text.SimpleDateFormat(pattern, Locale.getDefault()).format(Date(now))
    }

fun formatTime(now: Long): String = java.text.SimpleDateFormat("HH:mm", Locale.US).format(Date(now))

@Composable
fun nextAlarmText(): String? {
    val ctx = LocalContext.current
    val now = rememberNow()
    return remember(now / 60000) {
        ctx.getSystemService(AlarmManager::class.java)?.nextAlarmClock?.triggerTime?.let { formatTime(it) }
    }
}

fun greeting(hour: Int) = when (hour) {
    in 5..11 -> "صبح بخیر ☀️"
    in 12..16 -> "ظهر بخیر 🌿"
    in 17..20 -> "عصر بخیر 🌤"
    else -> "شب بخیر 🌙"
}

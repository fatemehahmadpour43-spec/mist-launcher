package com.mist.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/* ---------------- تنظیمات ذخیره‌شده ---------------- */

class LauncherPrefs(context: Context) {
    private val sp = context.getSharedPreferences("mist", Context.MODE_PRIVATE)
    private val cache = mutableStateMapOf<String, String>()

    init {
        sp.all.forEach { (k, v) -> if (v is String) cache[k] = v }
    }

    fun get(key: String, def: String? = null): String? = cache[key] ?: def

    fun set(key: String, value: String?) {
        if (value == null) {
            cache.remove(key); sp.edit().remove(key).apply()
        } else {
            cache[key] = value; sp.edit().putString(key, value).apply()
        }
    }

    fun flag(key: String, def: Boolean) = get(key)?.toBooleanStrictOrNull() ?: def
    fun setFlag(key: String, on: Boolean) = set(key, on.toString())

    fun list(key: String): List<String> =
        get(key)?.split('|')?.filter { it.isNotBlank() } ?: emptyList()

    fun setList(key: String, items: List<String>) = set(key, items.joinToString("|"))
}

/* ---------------- برنامه‌ها ---------------- */

data class AppInfo(
    val label: String,
    val pkg: String,
    val activity: String,
    val icon: ImageBitmap,
) {
    val id get() = "$pkg/$activity"
}

class AppRepository(private val context: Context) {
    suspend fun load(): List<AppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != context.packageName }
            .mapNotNull { ri ->
                runCatching {
                    AppInfo(
                        label = ri.loadLabel(pm).toString(),
                        pkg = ri.activityInfo.packageName,
                        activity = ri.activityInfo.name,
                        icon = ri.loadIcon(pm).toBitmap(144, 144).asImageBitmap(),
                    )
                }.getOrNull()
            }
            .sortedBy { it.label.lowercase() }
    }
}

fun Context.launchApp(app: AppInfo) = safeStart(
    Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(ComponentName(app.pkg, app.activity))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
)

fun Context.openAppInfo(app: AppInfo) = safeStart(
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
)

fun Context.safeStart(intent: Intent): Boolean = try {
    startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
} catch (e: Exception) {
    Toast.makeText(this, "برنامه‌ای برای این کار پیدا نشد", Toast.LENGTH_SHORT).show(); false
}

/** برنامه‌های پیش‌فرض یک پوشه: اول از روی بسته‌های پیشنهادی، بعد هر چه نصب است. */
fun pickDefaults(apps: List<AppInfo>, candidates: List<String>, skip: Int = 0): List<AppInfo> {
    val found = candidates.mapNotNull { c -> apps.firstOrNull { it.pkg == c } }
    val rest = apps.filter { it !in found }.drop(skip)
    return (found + rest).take(4)
}

/* ---------------- کمک‌ها ---------------- */

val LocalLauncher = compositionLocalOf<LauncherState> { error("no launcher state") }

class LauncherState(
    val prefs: LauncherPrefs,
    val apps: List<AppInfo>,
    val pickImage: (key: String) -> Unit,
    val openDialog: (DialogRequest) -> Unit,
    val openDrawer: (focusSearch: Boolean) -> Unit,
) {
    val mono get() = prefs.flag("mono_icons", true)
    val jalali get() = prefs.flag("jalali", true)
    val faDigits get() = prefs.flag("fa_digits", false)
    fun appById(id: String) = apps.firstOrNull { it.id == id }
}

sealed interface DialogRequest {
    data class EditText(val key: String, val title: String, val default: String) : DialogRequest
    data class PickApps(val key: String, val current: List<String>) : DialogRequest
    data object Countdown : DialogRequest
    data object Settings : DialogRequest
}

fun String.digits(fa: Boolean): String =
    if (!fa) this else map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

@Composable
fun rememberNow(): Long {
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(1000 - value % 1000)
        }
    }
    return now
}

@Composable
fun rememberUriBitmap(uri: String?, maxSize: Int = 1280): ImageBitmap? {
    val context = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, uri) {
        value = uri?.let {
            withContext(Dispatchers.IO) {
                runCatching { decodeScaled(context, Uri.parse(it), maxSize) }.getOrNull()
            }
        }
    }
    return bmp
}

private fun decodeScaled(context: Context, uri: Uri, max: Int): ImageBitmap {
    val src = ImageDecoder.createSource(context.contentResolver, uri)
    return ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
        val w = info.size.width
        val h = info.size.height
        val scale = max.toFloat() / maxOf(w, h)
        if (scale < 1f) decoder.setTargetSize((w * scale).toInt(), (h * scale).toInt())
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
    }.asImageBitmap()
}
